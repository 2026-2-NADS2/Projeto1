﻿using Microsoft.Data.Sqlite;
using System.Globalization;

namespace AULA06_ListaAlunos
{
    internal class AlunoDB
    {
        private readonly string _connectionString;

        public AlunoDB(string caminhoBanco)
        {

            _connectionString = $"Data Source={caminhoBanco}";
            CriarTabelaSeNaoExistir();
        }

        private void CriarTabelaSeNaoExistir()
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                CREATE TABLE IF NOT EXISTS Aluno (
                    Matricula TEXT NOT NULL PRIMARY KEY,
                    Nome      TEXT NOT NULL,
                    Turma     TEXT NOT NULL,
                    Media     REAL NOT NULL
                );
            ";
            comando.ExecuteNonQuery();
        }

        public void Inserir(Aluno item)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                INSERT INTO Aluno (Matricula, Nome, Turma, Media)
                VALUES (@matricula, @nome, @turma, @media);
            ";
            comando.Parameters.AddWithValue("@matricula", item.Matricula);
            comando.Parameters.AddWithValue("@nome", item.Nome);
            comando.Parameters.AddWithValue("@turma", item.Turma);
            comando.Parameters.AddWithValue("@media", item.Media);

            comando.ExecuteNonQuery();
        }

        public void Atualizar(Aluno item)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                UPDATE Aluno
                   SET Nome  = @nome,
                       Turma = @turma,
                       Media = @media
                 WHERE Matricula = @matricula;
            ";
            comando.Parameters.AddWithValue("@matricula", item.Matricula);
            comando.Parameters.AddWithValue("@nome", item.Nome);
            comando.Parameters.AddWithValue("@turma", item.Turma);
            comando.Parameters.AddWithValue("@media", item.Media);

            comando.ExecuteNonQuery();
        }

        public void Excluir(string matricula)
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                DELETE FROM Aluno
                 WHERE Matricula = @matricula;
            ";
            comando.Parameters.AddWithValue("@matricula", matricula);

            comando.ExecuteNonQuery();
        }

        public Aluno? ObterPorMatricula(string matricula)
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                SELECT Matricula, Nome, Turma, Media
                  FROM Aluno
                 WHERE Matricula = @matricula;
            ";
            comando.Parameters.AddWithValue("@matricula", matricula);

            using var reader = comando.ExecuteReader();

            if (reader.Read())
            {
                return new Aluno
                {
                    Matricula = reader.GetString(0),
                    Nome = reader.GetString(1),
                    Turma = reader.GetString(2),
                    Media = reader.GetDouble(3)
                };
            }

            return null;
        }

        public List<Aluno> ObterTodos()
        {
            var lista = new List<Aluno>();

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                SELECT Matricula, Nome, Turma, Media
                  FROM Aluno
              ORDER BY Nome;
            ";

            string matricula;
            string nome;
            string turma;
            double media;
            Aluno aluno;
            using var reader = comando.ExecuteReader();
            while (reader.Read())
            {
                matricula = reader.GetString(0);
                nome = reader.GetString(1);
                turma = reader.GetString(2);
                media = reader.GetDouble(3);
                aluno = new Aluno(matricula, nome, turma, media);
                lista.Add(aluno);
            }

            return lista;
        }

        public List<Aluno> ObterPorTurma(string turma)
        {
            var lista = new List<Aluno>();

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                SELECT Matricula, Nome, Turma, Media
                  FROM Aluno
                 WHERE Turma = @turma
              ORDER BY Nome;
            ";
            comando.Parameters.AddWithValue("@turma", turma);

            string matricula;
            string nome;
            string turmaLida;
            double media;
            Aluno aluno;
            using var reader = comando.ExecuteReader();
            while (reader.Read())
            {
                matricula = reader.GetString(0);
                nome = reader.GetString(1);
                turmaLida = reader.GetString(2);
                media = reader.GetDouble(3);
                aluno = new Aluno(matricula, nome, turmaLida, media);
                lista.Add(aluno);
            }

            return lista;
        }

        public List<Aluno> ObterComMediaIgualOuSuperior(double media)
        {
            var lista = new List<Aluno>();

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                SELECT Matricula, Nome, Turma, Media
                  FROM Aluno
                 WHERE Media >= @media
              ORDER BY Media DESC;
            ";
            comando.Parameters.AddWithValue("@media", media);

            string matricula;
            string nome;
            string turma;
            double mediaLida;
            Aluno aluno;
            using var reader = comando.ExecuteReader();
            while (reader.Read())
            {
                matricula = reader.GetString(0);
                nome = reader.GetString(1);
                turma = reader.GetString(2);
                mediaLida = reader.GetDouble(3);
                aluno = new Aluno(matricula, nome, turma, mediaLida);
                lista.Add(aluno);
            }

            return lista;
        }

        public void InserirOuAtualizar(Aluno item)
        {
            var existente = ObterPorMatricula(item.Matricula);

            if (existente == null)
                Inserir(item);
            else
                Atualizar(item);
        }

    }
}
