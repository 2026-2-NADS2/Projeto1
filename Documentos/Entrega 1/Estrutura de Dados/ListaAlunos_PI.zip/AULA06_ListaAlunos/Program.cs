﻿using AULA06_ListaAlunos;
using System.Globalization;


Console.OutputEncoding = System.Text.Encoding.UTF8;

string caminhoCsv = @"..\..\..\ALUNOS.csv";
string caminhoBanco = @"..\..\..\Alunos.db";
var repositorio = new AlunoDB(caminhoBanco);

Console.WriteLine("=== Simulação de Listagem de Alunos (Paginada) ===");
Console.WriteLine($"Banco SQLite: {caminhoBanco}");
Console.WriteLine();

if (!File.Exists(caminhoCsv))
{
    Console.WriteLine("Arquivo CSV não encontrado.");
    return;
}

int quantidadeImportada = ImportarCsv(caminhoCsv, repositorio);

Console.WriteLine();
Console.WriteLine($"Importação concluída. Registros processados: {quantidadeImportada}");
Console.WriteLine();

// 1) Banco de dados -> buscar os alunos -> colocar em uma lista/coleção
List<Aluno> alunos = repositorio.ObterTodos();

if (alunos.Count == 0)
{
    Console.WriteLine("Nenhum aluno cadastrado.");
    return;
}

// 2) Dividir os alunos em páginas e mostrar uma página por vez
const int tamanhoPagina = 5;
ExibirListagemPaginada(alunos, tamanhoPagina);


// ---------- Funções auxiliares ----------

void ExibirListagemPaginada(List<Aluno> lista, int itensPorPagina)
{
    int totalAlunos = lista.Count;
    int totalPaginas = (int)Math.Ceiling(totalAlunos / (double)itensPorPagina);
    int paginaAtual = 1;
    bool sair = false;

    while (!sair)
    {
        List<Aluno> pagina = ObterPagina(lista, paginaAtual, itensPorPagina);
        ExibirPagina(pagina, paginaAtual, totalPaginas, totalAlunos, itensPorPagina);

        Console.WriteLine();
        Console.WriteLine("[P] Próxima página   [A] Página anterior   [I] Ir para página   [Q] Sair");
        Console.Write("> ");
        string? opcao = Console.ReadLine()?.Trim().ToUpperInvariant();

        switch (opcao)
        {
            case "P":
                if (paginaAtual < totalPaginas)
                    paginaAtual++;
                else
                    Console.WriteLine("Você já está na última página.");
                break;

            case "A":
                if (paginaAtual > 1)
                    paginaAtual--;
                else
                    Console.WriteLine("Você já está na primeira página.");
                break;

            case "I":
                Console.Write($"Digite o número da página (1 a {totalPaginas}): ");
                string? entradaPagina = Console.ReadLine();
                if (int.TryParse(entradaPagina, out int numeroPagina) &&
                    numeroPagina >= 1 && numeroPagina <= totalPaginas)
                {
                    paginaAtual = numeroPagina;
                }
                else
                {
                    Console.WriteLine("Página inválida.");
                }
                break;

            case "Q":
                sair = true;
                break;

            default:
                Console.WriteLine("Opção inválida.");
                break;
        }

        Console.WriteLine();
    }
}

// 2) Divide a lista completa e devolve apenas os itens da página solicitada
List<Aluno> ObterPagina(List<Aluno> lista, int numeroPagina, int itensPorPagina)
{
    return lista
        .Skip((numeroPagina - 1) * itensPorPagina)
        .Take(itensPorPagina)
        .ToList();
}

// 3) Mostra uma página por vez no console
void ExibirPagina(List<Aluno> pagina, int paginaAtual, int totalPaginas, int totalAlunos, int itensPorPagina)
{
    Console.Clear();
    Console.WriteLine("=== Listagem de Alunos ===");
    Console.WriteLine($"Página {paginaAtual} de {totalPaginas}   (Total de alunos: {totalAlunos})");
    Console.WriteLine(new string('-', 60));

    int primeiroIndice = (paginaAtual - 1) * itensPorPagina + 1;
    int posicao = primeiroIndice;

    foreach (var aluno in pagina)
    {
        Console.WriteLine($"{posicao,3}. Matrícula: {aluno.Matricula} | Nome: {aluno.Nome} | Turma: {aluno.Turma} | Média: {aluno.Media:F2}");
        posicao++;
    }

    Console.WriteLine(new string('-', 60));
}


Aluno Converter(string[] item)
{
    string matricula = item[0];
    string nome = item[1];
    string turma = item[2];
    double media = double.Parse(item[3], CultureInfo.GetCultureInfo("pt-BR"));

    return new Aluno(matricula, nome, turma, media);
}

int ImportarCsv(string caminho, AlunoDB appDB)
{
    int contador = 0;
    if (File.Exists(caminho))
    {
        // O 'using' garante que o arquivo será fechado corretamente
        using (StreamReader sr = new StreamReader(caminho))
        {
            string? linha = sr.ReadLine(); //Desconsidera Cabeçalho
            while ((linha = sr.ReadLine()) != null)
            {
                string[] item = linha.Split(';');

                Aluno alu = Converter(item);
                appDB.InserirOuAtualizar(alu);
                contador++;
            }
        }
    }
    return contador;
}
