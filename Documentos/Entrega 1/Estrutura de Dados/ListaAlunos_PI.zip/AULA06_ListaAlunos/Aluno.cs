﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AULA06_ListaAlunos
{
    internal class Aluno
    {
        public string Matricula { get; set; }
        public string Nome { get; set; }
        public string Turma { get; set; }
        public double Media { get; set; }

        public Aluno()
        {
            Matricula = string.Empty;
            Nome = string.Empty;
            Turma = string.Empty;
        }

        public Aluno(string matricula, string nome, string turma, double media)
        {
            Matricula = matricula;
            Nome = nome;
            Turma = turma;
            Media = media;
        }

        public override string ToString()
        {
            return $"{Matricula} ; {Nome} ; {Turma} ; {Media.ToString("F2", CultureInfo.GetCultureInfo("pt-BR"))}";
        }

    }
}
